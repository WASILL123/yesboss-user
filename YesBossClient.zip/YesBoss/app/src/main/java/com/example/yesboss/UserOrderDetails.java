package com.example.yesboss;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ViewFlipper;

import static java.security.AccessController.getContext;

public class UserOrderDetails extends AppCompatActivity {

    ViewFlipper viewFlipper;
    FragmentManager fragmentManager;
    Button button4;
    int gallery_grid_Images[] = {android.R.drawable.ic_media_ff, android.R.drawable.btn_default, android.R.drawable.ic_btn_speak_now};


    private void setFlipperImage(int res) {
        ImageView image = new ImageView(this);
        image.setBackgroundResource(res);
        viewFlipper.addView(image);
        viewFlipper.setAutoStart(true);
        viewFlipper.setClickable(true);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_order_details);
        button4=findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent mainPage= new Intent(UserOrderDetails.this,MainPage.class);
                    startActivity(mainPage);
            }
//            @Override
//            public void onClick(View v) {
//                String user=username.getEditText().getText().toString();
//                String pass=password.getEditText().getText().toString();
//                if(user.equals("ad")){
//                    progress1.setVisibility(View.VISIBLE);
//                Intent mainPage= new Intent(MainActivity.this,MainPage.class);
//                    startActivity(mainPage);
//
//                }
//                else
//                {
//                    errorText.setText("Invalid Login Details");
//                  }
//
//
//            }
//        });
        });
    }
}


