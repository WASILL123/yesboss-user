package com.example.yesboss;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ExampleAdapter extends RecyclerView.Adapter<ExampleAdapter.ExampleViewHolder> {
    private  ArrayList<itemonrecycler> mExampleList;
    private OnItemClickListener mlistener;

    public interface OnItemClickListener{
        void onItemClick(int position);
    }
    public void setOnItemClickListener  (OnItemClickListener listener){
        mlistener = listener;
    }

    public static class ExampleViewHolder  extends RecyclerView.ViewHolder{
        public ImageView mImageView;
//        public TextView mTextView1;
        public TextView mTextView2;
        public TextView mTextView3;



        public ExampleViewHolder(View itemView, final OnItemClickListener listener) {
            super(itemView);
            mImageView=itemView.findViewById(R.id.IV_item_on_recycler);
//            mTextView1=itemView.findViewById(R.id.TV_item_on_recycler);
            mTextView2=itemView.findViewById(R.id.TV2_item_on_recycler);
            mTextView3=itemView.findViewById(R.id.TV3_item_on_recycler);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(listener != null){
                        int position = getAdapterPosition();
                        if(position != RecyclerView.NO_POSITION){
                            listener.onItemClick(position);
                        }
                    }
                }
            });
        }
    }

    public ExampleAdapter(ArrayList<itemonrecycler> exampleList){
        mExampleList=exampleList;
    }

    @NonNull
    @Override
    public ExampleViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_on_recycler, parent , false);
        ExampleViewHolder evh =new ExampleViewHolder(v,mlistener);
        return evh;
    }

    @Override
    public void onBindViewHolder(@NonNull ExampleViewHolder holder, int position) {
    itemonrecycler currentItem=mExampleList.get(position);
    holder.mImageView.setImageResource(currentItem.getmImageReource());
//    holder.mTextView1.setText(currentItem.getText1());
    holder.mTextView2.setText(currentItem.getText2());
        holder.mTextView3.setText(currentItem.getText3());
    }

    @Override
    public int getItemCount() {
        return mExampleList.size();
    }
}
