package com.example.yesboss;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeFragment extends Fragment {
    Button test_button;
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private  RecyclerView.LayoutManager mLayoutManager;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rott_view= inflater.inflate(R.layout.fragment_home,container,false);
//        test_button= rott_view.findViewById(R.id.test_button);
        final ArrayList<itemonrecycler> itemonrecyclers=new ArrayList<>();
        itemonrecyclers.add(new itemonrecycler(R.drawable.ic_checklist,"9:15am","pending"));
        itemonrecyclers.add(new itemonrecycler(R.drawable.ic_person,"9:15am","pending"));
        itemonrecyclers.add(new itemonrecycler(R.drawable.common_google_signin_btn_icon_dark_normal,"9:15am","pending"));

        mRecyclerView= rott_view.findViewById(R.id.RC1);
        mRecyclerView.setHasFixedSize(true);
        mAdapter=new ExampleAdapter(itemonrecyclers);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);


        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(getContext(),UserOrderDetails.class);
                itemonrecycler clickedItem = itemonrecyclers.get(position);
                startActivity(intent);

            }
        });


//mAdapter.setOnItemClickListener(new )
//
//        mAdapter.setOnItemClickListener((position){
//            Intent intent=new Intent(getContext().UserOderDetails.class);
//            itemonrecycler clickedItem=mRecyclerView.get(position);
//            startActivity(intent);
//                });

//        test_button.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public  void onClick(View v){
//                startActivity(new Intent(getActivity(),UserOrderDetails.class));
//            }
//        });
        return rott_view;
    }
//    private class RecyclerViewHolder extends  RecyclerView.ViewHolder{
//        private CardView mCardView;
//        private TextView mTextView;
//
//        public RecyclerViewHolder(View viewItem){
//            super(viewItem);
//        }
//        public RecyclerViewHolder(LayoutInflater inflater,ViewGroup container){
//            super(inflater.inflate(R.layout.card_view,container,false));
//        }
    }





