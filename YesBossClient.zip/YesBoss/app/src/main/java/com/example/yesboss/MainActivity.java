package com.example.yesboss;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    FirebaseAuth mAuth;
    FirebaseUser mUser;
    TextInputLayout username;
    TextInputLayout password;
    ProgressBar progress1;
    TextView errorText;
    Button login1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth=FirebaseAuth.getInstance();
        mUser=FirebaseAuth.getInstance().getCurrentUser();
        username=findViewById(R.id.user_ID_layout);
        password=findViewById(R.id.password_login_layout);
        progress1=findViewById(R.id.progressBar);
        errorText=findViewById(R.id.errorText);
        findViewById(R.id.login).setOnClickListener(this);
        progress1.setVisibility(View.INVISIBLE);
//        login1.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String user=username.getEditText().getText().toString();
//                String pass=password.getEditText().getText().toString();
//                if(user.equals("ad")){
//                    progress1.setVisibility(View.VISIBLE);
//                Intent mainPage= new Intent(MainActivity.this,MainPage.class);
//                    startActivity(mainPage);
//
//                }
//                else
//                {
//                    errorText.setText("Invalid Login Details");
//                  }
//
//
//            }
//        });
if(mUser!=null){
    finish();
    startActivity(new Intent(MainActivity.this, MainPage.class));
}
    }
    private void userLogin(){

        String user=username.getEditText().getText().toString().trim();
        String pass=password.getEditText().getText().toString().trim();

        if(user.isEmpty() && pass.isEmpty()){username.setError("Email is Required");
        password.setError("Password is Required");
        username.requestFocus();
        return;}

    mAuth.signInWithEmailAndPassword(user,pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
        @Override
        public void onComplete(@NonNull Task<AuthResult> task) {
            if(task.isSuccessful()){
                Intent mainPage= new Intent( MainActivity.this, MainPage.class);

                mainPage.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                mainPage.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                mainPage.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);

                startActivity(mainPage);
                finish();
            }else{
                Toast.makeText(getApplicationContext(),task.getException().getMessage(), Toast.LENGTH_LONG).show();
            }
        }
    });

    }

    @Override
    public void onClick(View v) {
        userLogin();
    }
    @Override
    public void onSaveInstanceState(Bundle outState, PersistableBundle outPersistentState) {
        super.onSaveInstanceState(outState, outPersistentState);
    }
    @Override
    public void onBackPressed() {
        if(mUser==null){
            Intent a = new Intent(Intent.ACTION_MAIN);
            a.addCategory(Intent.CATEGORY_HOME);
            a.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            a.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(a);
    }
    else
        {
            super.onBackPressed();
        }
    }
}
