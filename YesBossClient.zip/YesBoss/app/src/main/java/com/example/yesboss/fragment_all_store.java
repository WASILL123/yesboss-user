package com.example.yesboss;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.util.ArrayList;



public class fragment_all_store extends Fragment {
    Button test_button;
    private RecyclerView mRecyclerView;
    private ExampleAdapter mAdapter;
    private  RecyclerView.LayoutManager mLayoutManager;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rott_view= inflater.inflate(R.layout.fragment_fragment_all_store,container,false);
//        test_button= rott_view.findViewById(R.id.test_button);
        final ArrayList<itemonrecycler> itemonrecyclers=new ArrayList<>();
        itemonrecyclers.add(new itemonrecycler(R.drawable.ic_checklist,"9:15am","pending"));
        itemonrecyclers.add(new itemonrecycler(R.drawable.ic_person,"9:15am","pending"));
        itemonrecyclers.add(new itemonrecycler(R.drawable.common_google_signin_btn_icon_dark_normal,"9:15am","pending"));

        mRecyclerView= rott_view.findViewById(R.id.RC1);
        mRecyclerView.setHasFixedSize(true);
        mAdapter=new ExampleAdapter(itemonrecyclers);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.setAdapter(mAdapter);


        mAdapter.setOnItemClickListener(new ExampleAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(int position) {
                Intent intent = new Intent(getContext(),UserOrderDetails.class);
                itemonrecycler clickedItem = itemonrecyclers.get(position);
                startActivity(intent);

            }
        });
        return rott_view;
    }
//    private class RecyclerViewHolder extends  RecyclerView.ViewHolder{
//        private CardView mCardView;
//        private TextView mTextView;
//
//        public RecyclerViewHolder(View viewItem){
//            super(viewItem);
//        }
//        public RecyclerViewHolder(LayoutInflater inflater,ViewGroup container){
//            super(inflater.inflate(R.layout.card_view,container,false));
//        }
}
